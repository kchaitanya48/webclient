package com.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.DentalClaim;

@RestController//(value="controller")
@RequestMapping(value="/controller")
public class DemoController {

	@RequestMapping(value="/details",
			method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public DentalClaim  getDentalClaim(@RequestBody DentalClaim dc){
		/*DentalClaim dc=new DentalClaim();
		List<Integer> list=new ArrayList<>();
		list.add(5551);
		list.add(5552);
		list.add(5553);
		dc.setClmSeqNum(4444);
		dc.setClmLnSeqNum(list);
		System.out.println(" id ===> "+id);*/
		System.out.println("clmSeqNum "+dc.getClmSeqNum()+" ClmSeqLnNUm "+dc.getClmLnSeqNum());
		dc.setClmSeqNum(7979);
		return dc;
	}
}
