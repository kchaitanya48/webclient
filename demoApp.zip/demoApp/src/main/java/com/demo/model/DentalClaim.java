package com.demo.model;

import java.util.List;

public class DentalClaim {

	private Integer clmSeqNum;
	
	private List<Integer> clmLnSeqNum;
	
	private String test;
	
	

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}

	public Integer getClmSeqNum() {
		return clmSeqNum;
	}

	public void setClmSeqNum(Integer clmSeqNum) {
		this.clmSeqNum = clmSeqNum;
	}

	public List<Integer> getClmLnSeqNum() {
		return clmLnSeqNum;
	}

	public void setClmLnSeqNum(List<Integer> clmLnSeqNum) {
		this.clmLnSeqNum = clmLnSeqNum;
	}
	
	
	
}
