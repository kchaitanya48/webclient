package com.sample.model;

import java.util.List;

public class DentalClaim {

	private Integer clmSeqNum;

	private List<Integer> clmLnSeqNum;

	private String dcn;

	private String dcnSplitNum;

	private String clmntNum;

	public Integer getClmSeqNum() {
		return clmSeqNum;
	}

	public void setClmSeqNum(Integer clmSeqNum) {
		this.clmSeqNum = clmSeqNum;
	}

	public List<Integer> getClmLnSeqNum() {
		return clmLnSeqNum;
	}

	public void setClmLnSeqNum(List<Integer> clmLnSeqNum) {
		this.clmLnSeqNum = clmLnSeqNum;
	}

	public String getDcn() {
		return dcn;
	}

	public void setDcn(String dcn) {
		this.dcn = dcn;
	}

	public String getDcnSplitNum() {
		return dcnSplitNum;
	}

	public void setDcnSplitNum(String dcnSplitNum) {
		this.dcnSplitNum = dcnSplitNum;
	}

	public String getClmntNum() {
		return clmntNum;
	}

	public void setClmntNum(String clmntNum) {
		this.clmntNum = clmntNum;
	}

}
